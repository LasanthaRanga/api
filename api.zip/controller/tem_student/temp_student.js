const con = require('../../util/sequl');
const course = con.import('../../models/course');
const student = con.import('../../models/temp_student');
const status = con.import('../../models/status_student');
const db = require('../../util/con');

exports.getStudent = (req, res, next) => {
    try {
        console.log('user ' + req.body.userid);
        db.execute("SELECT privilages.id,privilages.title,privilages.url,privilages.icon,user_has_privilages.userid FROM user_has_privilages INNER JOIN privilages ON user_has_privilages.privid=privilages.id ",
            (error, rows, fildData) => {
                if (!error) {
                    res.send(rows);
                }
            });
    } catch (error) {
        console.log(error);
        res.status(500).send(error);
    }
}

exports.createStudent = (req, res, next) => {
    try {
        student.create({
            name: req.body.name,
            nic: req.body.nic,
            mob1: req.body.mob1,
            mob2: req.body.mob2,
            city: req.body.city,
            description: req.body.description,
            other1: req.body.other1,
            other2: req.body.other2,
            course: req.body.course,
            isActive: req.body.status

        }).then(result => {
            res.send(result);
        });
    } catch (error) {
        console.log(error);
        res.status(500).send(error);
    }
}